package NoobQ;

public class Sum {

	public static void main(String[] args) {
		int a=5, b=8, ans;
		
		ans=a+b;
		
		System.out.print(ans);

	}

}
