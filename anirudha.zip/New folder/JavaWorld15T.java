package NoobQ;

public class JavaWorld15T {

	public static void main(String[] args) {
		
		for(int i=0;i<15;i++) {
			
			System.out.print("Java World !\n");
		}

	}

}
